This Assignment used Unity Standard Assets and edited sound samples from the royalty free Soniss Sound Library (https://sonniss.com/gameaudiogdc2017/)

Controls:
WASD - Move
SHIFT - Sprint
MOUSE - Look
LEFT CLICK - Hold to pick up ball
RIGHT CLICK - Click to throw picked up ball
ESCAPE - Quit Game


Notes:
Click the Red Button to spawn more balls!
Anything interactible and within range of the player is indicated by a brigh cyan highlight

Find the Standalone exe of the build in the Han_Unity_Assignment_Standalone folder in this directory